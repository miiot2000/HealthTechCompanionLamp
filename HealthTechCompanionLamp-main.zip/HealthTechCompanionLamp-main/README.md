# HealthTechCompanionLamp
HealthTech Challenge Winter 2023 
